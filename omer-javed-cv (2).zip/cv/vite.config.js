import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base "./" makes the built site work on GitHub Pages at any address,
// e.g. https://username.github.io/omer-javed-cv/
export default defineConfig({
  base: "./",
  plugins: [react()],
});
